const table = document.getElementById("multi-table");
//ask me for my numbers
function generateTable() {
    
    const num1 = parseInt(prompt('Enter your first number'));
    const num2 = parseInt(prompt('Oya enter the second one oga'));
    const table = document.getElementById("multi-table");


            table.innerHTML = "";
        if (isNaN(num1) || isNaN(num2)) {
            alert(' please reload and enter valid numbers ')
            

        }
        else {      
            const headerRow = table.insertRow();
            const headerCell1 = headerRow.insertCell();
            const headerCell2 = headerRow.insertCell();
            const headerCell3 = headerRow.insertCell();
            const headerCell4 = headerRow.insertCell();

            headerCell1.textContent = "Number 1";
            headerCell2.textContent = "Number 2";
            headerCell3.textContent = "Number 3";
            headerCell4.textContent = "Product";


            for (let i = 1; i <= 50; i++) {
                const row = table.insertRow();
                const cell1 = row.insertCell();
                const cell2 = row.insertCell();
                const cell3 = row.insertCell();
                const cell4 = row.insertCell();
                cell1.textContent = num1;
                cell2.textContent = num2;
                cell3.textContent = i;
                cell4.textContent = num1 * num2 * i;
            }

        } 
    }



function clearTable() {

    table.innerHTML = "";
}

